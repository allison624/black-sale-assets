# Black Sale Legacy: paquete para Framer

Contenido
- BlackSaleLandingDesktop.tsx: landing Desktop
- BlackSaleLandingMobile.tsx: landing Mobile (vertical, centrada)
- BlackSaleThankYou.tsx: Thank you page (Desktop y Mobile, es responsive)
- assets/: imágenes y fuentes (solo las que se usan) + _headers y vercel.json (CORS)

## 1. Alojar la carpeta assets
Framer no sirve carpetas de archivos para código, así que sube `assets/` a un host estático con URL pública:
Cloudflare Pages, Netlify o Vercel (arrastrar la carpeta). Los archivos `_headers` (Netlify, Cloudflare) y
`vercel.json` (Vercel) ya activan CORS, necesario para que carguen las fuentes. Quedará algo como
`https://tu-proyecto.pages.dev` (la carpeta es la raíz). Esa URL es el valor de "Assets URL".

## 2. Crear los componentes en Framer
1. Assets > Code > New Component, nómbralo igual que el archivo.
2. Borra el contenido, pega todo el archivo .tsx y guarda. Repite con los 3.
3. Arrastra cada componente al lienzo. En el panel de propiedades completa "Assets URL".

## 3. Páginas y breakpoints
- Página Landing: Breakpoint Desktop con BlackSaleLandingDesktop, breakpoint Phone con BlackSaleLandingMobile.
  Cada uno con ancho Fill (100%) y alto Auto. Deja la página sin padding ni fondo (el componente trae su fondo negro).
- Página /gracias: BlackSaleThankYou, ancho Fill, alto Auto, en todos los breakpoints (se adapta solo).
- Ajusta los puntos de corte de Framer para que Phone coincida con la vista móvil (hasta 700 px aprox.).
- En Page settings de /gracias activa "noindex" (la página es posterior al registro).

## 4. Propiedades de cada componente
- Assets URL: obligatorio.
- Form endpoint (landings): URL que recibe el registro por POST JSON (nombre, apellido, email, pais, codigo, telefono, nivel,
  evento, origen). Vacío: el formulario avisa que no está conectado y NO simula éxito.
- Nivel requerido: activar cuando existan las opciones del select de nivel.
- Preview estados: dejar APAGADO al publicar (solo para revisar ?state=success|error|loading|unconfigured).
- WhatsApp URL (Thank you): link real del grupo. Vacío: el botón queda inerte y se ve "[Link del grupo]".

## 5. Flujo de registro a Thank you
Tras un envío correcto, redirige a /gracias desde tu sistema de leads (redirect del formulario o automatización).

## 6. Notas técnicas
- Todo el CSS está aislado bajo la clase `.bsl`: no afecta al resto del sitio de Framer.
- El JS se limpia al desmontar (listeners, timers, observers). No usa librerías externas.
- Respeta prefers-reduced-motion. En el lienzo de Framer se muestran todas las secciones ya reveladas y sin parallax.
- Los puntos de corte internos usan el ancho de la ventana, así que la vista previa fiel es la de Preview/sitio publicado,
  no el redimensionado del lienzo.
- Pendientes del cliente (siguen como marcadores, sin datos inventados): endpoint del formulario, opciones de nivel,
  link del grupo de WhatsApp, reseñas reales, "más de 15 países", arte 3D de cajas, chips de planes de pago.
